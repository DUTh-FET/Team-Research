1. Launch Matlab
2. Open App Designer
3. Open the file "QuantumMemristorDynamicFinal3.mlapp"
4. Run the app